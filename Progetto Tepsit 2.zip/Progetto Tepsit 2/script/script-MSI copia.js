$(document).ready(function(){
    $("#game").hide();

    //Funzioni per il menu principale
    $("#play").click(function(){ //Nasconde il menu principale e mostra il gioco
        $("#menu").hide();
        $("#game").show();
    });

    var difficult = 0;
    $("#difficult").click(function(){ //Cambia la difficoltà del gioco
        difficult++;

        switch(difficult){
            case 1: $("#starEasy").attr('name', "star");
                    $("#starMedium").attr('name', "star-outline");
                    $("#starHard").attr('name', "star-outline");
                    $("#modality").text("EASY");
                    break;
            
            case 2: $("#starEasy").attr('name', "star");
                    $("#starMedium").attr('name', "star");
                    $("#starHard").attr('name', "star-outline");
                    $("#modality").text("MEDIUM");
                    break;
            
            case 3: $("#starEasy").attr('name', "star");
                    $("#starMedium").attr('name', "star");
                    $("#starHard").attr('name', "star");
                    $("#modality").text("HARD");
                    break;
        }

        if(difficult == 3){
            difficult = 0;
        }
    });

    /*$(function() {
      $("div[name='play1'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6']").draggable();
        $("#result").droppable({
          drop: function(event, ui) {
            $(this).append(ui.draggable);
            ui.draggable.hide();
          }
      });
    });*/

    $(function() {
      var card, cardName, tot, i = 0; // dichiara la variabile card
      $("div[name='play1'],div[name='play2'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6'],div[name='play15'],div[name='play14'],div[name='play7'],div[name='play8'],div[name='play9'],div[name='play10'],div[name='play11'],div[name='play12'],div[name='play13']").draggable();
      $("#result").droppable({
        drop: function(event, ui) {
          // memorizza l'oggetto droppato nella variabile card
          card = ui.draggable;
          cardName = card.attr('name'); // salva il nome del div in cardName
          //alert("divname carta" + cardName);
          $(this).append(ui.draggable);
          ui.draggable.hide();
          i++;
          //alert(i);

          if(cardName == "play1"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + risultato1;
            $("#result").text(tot);
            //prossima carta in alto
            var $div = $("#due");
            newtot = avanti($div);
            //alert("nuovo totale" + newtot);
            //var risultato1 = avanti($div);
          }
          else if(cardName == "play15"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + risultato2;
            $("#result").text(tot);

            //prossima carta in basso
            var $div = $("#quattordici");
            newtot2 = avanti($div);
          }
          if(cardName == "play2"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);

            //prossima carta in alto
            var $div = $("#tre");
            newtot = avanti($div);
          }
          if(cardName == "play14"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);

            var $div = $("#tredici");
            newtot2 = avanti($div);
          }
          if(cardName == "play3"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);

            //prossima carta in alto
            var $div = $("#quattro");
            newtot = avanti($div);
          }
          if(cardName == "play4"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);

            //prossima carta in alto
            var $div = $("#cinque");
            newtot = avanti($div);
          }
          if(cardName == "play13"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);

            var $div = $("#dodici");
            newtot2 = avanti($div);
          }
          if(cardName == "play12"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);

            var $div = $("#undici");
            newtot2 = avanti($div);
          }
          if(cardName == "play5"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);

            //prossima carta in alto
            var $div = $("#sei");
            newtot = avanti($div);
          }
          if(cardName == "play6"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);

            //prossima carta in alto
            var $div = $("#sette");
            newtot = avanti($div);
          }
          if(cardName == "play11"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);

            var $div = $("#dieci");
            newtot2 = avanti($div);
          }
          if(cardName == "play10"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);

            var $div = $("#nove");
            newtot2 = avanti($div);
          }
          if(cardName == "play7"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);

            //prossima carta in alto
            var $div = $("#otto");
            newtot = avanti($div);
          }
          if(cardName == "play8"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);

            //prossima carta in alto
            var $div = $("#nove");
            newtot = avanti($div);
            newtot2 = avanti($div);
          }
          if(cardName == "play9"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);

            //prossima carta in alto
            var $div = $("#dieci");
            newtot = avanti($div);
          }
          if(cardName == "play16"){
            //modifica il testo del div con id result
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);

            var $div = $("#quindici");
            newtot2 = avanti($div);
          }

          if(tot <= 0 || tot >= 21){
            alert("Hai perso!!!");
            location.reload();
          }
          if(i == 15){
            alert("Hai vinto!!!");
            location.reload();
          }

        }
      });
    });


      /*$(function() {
        $("div[name='play1'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6']").draggable();
          $("#hold").droppable({
            drop: function(event, ui) {
            $(this).append(ui.draggable);
          }
        });
      });*/

      /*$(function(){
        var images = ["../images/testing.jpeg", "../images/2.jpg", "../images/3.jpg", "../images/4.jpg"];
        var random = images[Math.floor(Math.random() * images.length)];
        var indice = images[random]; // recuperiamo l'elemento dell'array corrispondente all'indice
        alert(indice);
  
        $("#uno").css("background-image", "url('" + random + "')");
        var random = images[Math.floor(Math.random() * images.length)];
        if(indice == 0){
          risultato = -6;
          alert(risultato);
        }
        $("#tre").css("background-image", "url('" + random + "')");
        var random = images[Math.floor(Math.random() * images.length)];
        $("#quattro").css("background-image", "url('" + random + "')");
        var random = images[Math.floor(Math.random() * images.length)];
        $("#cinque").css("background-image", "url('" + random + "')");
        var random = images[Math.floor(Math.random() * images.length)];
        $("#sei").css("background-image", "url('" + random + "')");

      });*/

      function calcoloris(indice){
        var risultato;

        if(indice == 0){
          risultato = 1;
          //alert(risultato);
        }
        else if(indice == 1){
          risultato = 2;
          //alert(risultato);
        }
        else if(indice == 2){
          risultato = 3;
          //alert(risultato);
        }
        else if(indice == 3){
          risultato = 4;
          //alert(risultato);
        }
        else if(indice == 4){
          risultato = 5;
          //alert(risultato);
        }
        else if(indice == 5){
          risultato = 6;
          //alert(risultato);
        }
        else if(indice == 6){
          risultato = 7;
          //alert(risultato);
        }
        else if(indice == 7){
          risultato = 8;
          //alert(risultato);
        }
        else if(indice == 8){
          risultato = 9;
          //alert(risultato);
        }
        else if(indice == 9){
          risultato = -1;
        }
        else if(indice == 10){
          risultato = -2;
        }
        else if(indice == 11){
          risultato = -3;
        }
        else if(indice == 12){
          risultato = -4;
        }
        else if(indice == 13){
          risultato = -5;
        }
        else if(indice == 14){
          risultato = -6;
        }
        else if(indice == 15){
          risultato = -7;
        }
        else if(indice == 16){
          risultato = -8;
        }
        else if(indice == 17){
          risultato = -9;
        }

        return risultato;

      };

      /*function avanti(div, ris){
        var images = ["../images/verde/1.png", "../images/verde/2.png", "../images/verde/3.png", "../images/verde/4.png", "../images/verde/5.png", "../images/verde/6.png", "../images/verde/7.png", "../images/verde/8.png", "../images/verde/9.png"];
        var randomIndex = Math.floor(Math.random() * images.length);
        var randomImage = images[randomIndex]; // recuperiamo l'elemento dell'array corrispondente all'indice
        var indice = randomIndex; // memorizza l'indice estratto dall'array
        //alert(indice);

        $("#due").css("background-image", "url('" + randomImage + "')");
        risultato1 = calcoloris(indice);
      };*/

      /*function avanti($div) {
        var images = ["../images/verde/1.png", "../images/verde/2.png", "../images/verde/3.png", "../images/verde/4.png", "../images/verde/5.png", "../images/verde/6.png", "../images/verde/7.png", "../images/verde/8.png", "../images/verde/9.png", "../images/rosso/1.png", "../images/rosso/2.png", "../images/rosso/3.png", "../images/rosso/4.png", "../images/rosso/5.png", "../images/rosso/6.png", "../images/rosso/7.png", "../images/rosso/8.png", "../images/rosso/9.png"];
        var randomIndex = Math.floor(Math.random() * images.length);
        var randomImage = images[randomIndex];
        var indice = randomIndex;

        $div.css("background-image", "url('" + randomImage + "')");
        var newris;
        newris = calcoloris(indice);
        //alert(newris);

        return newris;
      };*/

      $(function(){
        var images = ["../images/verde/1.png", "../images/verde/2.png", "../images/verde/3.png", "../images/verde/4.png", "../images/verde/5.png", "../images/verde/6.png", "../images/verde/7.png", "../images/verde/8.png", "../images/verde/9.png", "../images/rosso/1.png", "../images/rosso/2.png", "../images/rosso/3.png", "../images/rosso/4.png", "../images/rosso/5.png", "../images/rosso/6.png", "../images/rosso/7.png", "../images/rosso/8.png", "../images/rosso/9.png"];
        var randomIndex = Math.floor(Math.random() * images.length);
        var randomImage = images[randomIndex]; // recuperiamo l'elemento dell'array corrispondente all'indice
        var indice = randomIndex; // memorizza l'indice estratto dall'array
        //alert(indice);
        //alert(randomImage);

        $("#uno").css("background-image", "url('" + randomImage + "')");
        risultato1 = calcoloris(indice);

        var randomIndex = Math.floor(Math.random() * images.length);
        var randomImage = images[randomIndex];
        $("#quindici").css("background-image", "url('" + randomImage + "')");
        risultato2 = calcoloris(randomIndex);
      });

    $(function() {
      $("div[name='play1'],div[name='play2'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6'],div[name='play15'],div[name='play14'],div[name='play7'],div[name='play8'],div[name='play9'],div[name='play10'],div[name='play11'],div[name='play12'],div[name='play13'],div[name='play16']").draggable({
        revert: function(event, ui) { 
          $(this).data("uiDraggable").originalPosition = { 
            top: 0,
            left: 0
          };
          return !event;
        }
      });
    });

    $("#result, #hold").droppable({
      accept: function(draggable) {
        var cardName = draggable.attr('name');
        var cardNumber = parseInt(cardName.replace('play', ''));
        return (cardNumber < minCardNumber || cardNumber > maxCardNumber);
      }
    });

    var minCardNumber = 2;
    var maxCardNumber = 14;

    function avanti($div) {
      var images = ["../images/verde/1.png", "../images/verde/2.png", "../images/verde/3.png", "../images/verde/4.png", "../images/verde/5.png", "../images/verde/6.png", "../images/verde/7.png", "../images/verde/8.png", "../images/verde/9.png", "../images/rosso/1.png", "../images/rosso/2.png", "../images/rosso/3.png", "../images/rosso/4.png", "../images/rosso/5.png", "../images/rosso/6.png", "../images/rosso/7.png", "../images/rosso/8.png", "../images/rosso/9.png"];
      var randomIndex = Math.floor(Math.random() * images.length);
      var randomImage = images[randomIndex];
      var indice = randomIndex;

      $div.css("background-image", "url('" + randomImage + "')");
      var newris;
      newris = calcoloris(indice);
      var cardName = $div.attr('name');
      var cardNumber = parseInt(cardName.replace('play', ''));

      if(cardNumber > 0 && cardNumber < 9){
        minCardNumber++;
      }

      else if(cardNumber > 8 && cardNumber < 16){
        maxCardNumber--;
      }

      return newris;
    }

    /*$(function() {
      $("div[name='play1'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6']").draggable();
      $("#hold").droppable({
        drop: function(event, ui) {
          $(this).text("");
          $(this).append(ui.draggable);
          $("#hold div").css({"margin":"0", "padding":"0", "width":"96px", "height":"127px"});
        }
      });
    });*/

    //quando premo il bottone con id reload si aggiorna la pagina
    $("#reload").click(function(){
      location.reload();
    });



      


 


});