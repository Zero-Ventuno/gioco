$(document).ready(function () {
  $("#game").hide();
  $("#regulation").hide();

  $("#play").click(function () {
    $("#menu").hide();
    $("#regulation").hide();
    $("#game").show();
  });

  $("#rules").click(function () {
    $("#menu").hide();
    $("#game").hide();
    $("#regulation").show();
  });

  $("#back").click(function () {
    $("#menu").show();
    $("#game").hide();
    $("#regulation").hide();
  });

  $(function () {
    var card, cardName, tot, i = 0; // dichiara la variabile card
    $("div[name='play1'],div[name='play2'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6'],div[name='play15'],div[name='play14'],div[name='play7'],div[name='play8'],div[name='play9'],div[name='play10'],div[name='play11'],div[name='play12'],div[name='play13']").draggable();
    $("#result").droppable({
      drop: function (event, ui) {
        // memorizza l'oggetto droppato nella variabile card
        card = ui.draggable;
        cardName = card.attr('name'); // salva il nome del div in cardName
        //alert("divname carta" + cardName);
        $(this).append(ui.draggable);
        ui.draggable.hide();

        /*if (cardName == "play1") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + risultato1;
          $("#result").text(tot);
          //prossima carta in alto
          if(hold == false){
            var $div = $("#due");
            newtot = avanti($div);
          }
          hold = false;
          //alert("nuovo totale" + newtot);
          //var risultato1 = avanti($div);
        }
        else if (cardName == "play15") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + risultato2;
          $("#result").text(tot);
          if(hold == false){
            //prossima carta in basso
            var $div = $("#quattordici");
            newtot2 = avanti($div);
          }

          hold = false;
        }
        if (cardName == "play2") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot;
          $("#result").text(tot);

          //prossima carta in alto
          var $div = $("#tre");
          newtot = avanti($div);
        }
        if (cardName == "play14") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot2;
          $("#result").text(tot);

          var $div = $("#tredici");
          newtot2 = avanti($div);
        }
        if (cardName == "play3") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot;
          $("#result").text(tot);

          //prossima carta in alto
          var $div = $("#quattro");
          newtot = avanti($div);
        }
        if (cardName == "play4") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot;
          $("#result").text(tot);

          //prossima carta in alto
          var $div = $("#cinque");
          newtot = avanti($div);
        }
        if (cardName == "play13") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot2;
          $("#result").text(tot);

          var $div = $("#dodici");
          newtot2 = avanti($div);
        }
        if (cardName == "play12") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot2;
          $("#result").text(tot);

          var $div = $("#undici");
          newtot2 = avanti($div);
        }
        if (cardName == "play5") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot;
          $("#result").text(tot);

          //prossima carta in alto
          var $div = $("#sei");
          newtot = avanti($div);
        }
        if (cardName == "play6") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot;
          $("#result").text(tot);

          //prossima carta in alto
          var $div = $("#sette");
          newtot = avanti($div);
        }
        if (cardName == "play11") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot2;
          $("#result").text(tot);

          var $div = $("#dieci");
          newtot2 = avanti($div);
        }
        if (cardName == "play10") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot2;
          $("#result").text(tot);

          var $div = $("#nove");
          newtot2 = avanti($div);
        }
        if (cardName == "play7") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot;
          $("#result").text(tot);

          //prossima carta in alto
          var $div = $("#otto");
          newtot = avanti($div);
        }
        if (cardName == "play8") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot;
          $("#result").text(tot);

          //prossima carta in alto
          var $div = $("#nove");
          newtot = avanti($div);
          newtot2 = avanti($div);
        }
        if (cardName == "play9") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot2;
          $("#result").text(tot);

          //prossima carta in alto
          var $div = $("#dieci");
          newtot = avanti($div);
        }
        if (cardName == "play16") {
          //modifica il testo del div con id result
          tot = parseInt($("#result").text()) + newtot2;
          $("#result").text(tot);

          var $div = $("#quindici");
          newtot2 = avanti($div);
        }*/
        switch (cardName) {
          case "play1":
            i++;
            tot = parseInt($("#result").text()) + risultato1;
            $("#result").text(tot);
            var $div = $("#due");
            newtot = avanti($div);
            break;

          case "play15":
            i++;
            tot = parseInt($("#result").text()) + risultato2;
            $("#result").text(tot);
            var $div = $("#quattordici");
            newtot2 = avanti($div);
            break;

          case "play2":
            i++;
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);
            var $div = $("#tre");
            newtot = avanti($div);
            break;

          case "play14":
            i++;
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);
            var $div = $("#tredici");
            newtot2 = avanti($div);
            break;

          case "play3":
            i++;
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);
            var $div = $("#quattro");
            newtot = avanti($div);
            break;

          case "play4":
            i++;
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);
            var $div = $("#cinque");
            newtot = avanti($div);
            break;

          case "play13":
            i++;
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);
            var $div = $("#dodici");
            newtot2 = avanti($div);
            break;

          case "play12":
            i++;
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);
            var $div = $("#undici");
            newtot2 = avanti($div);
            break;

          case "play5":
            i++;
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);
            var $div = $("#sei");
            newtot = avanti($div);
            break;

          case "play6":
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);
            var $div = $("#sette");
            newtot = avanti($div);
            i++;
            break;

          case "play11":
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);
            var $div = $("#dieci");
            newtot2 = avanti($div);
            i++;
            break;

          case "play10":
            i++;
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);
            var $div = $("#nove");
            newtot2 = avanti($div);
            break;

          case "play7":
            i++;
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);
            var $div = $("#otto");
            newtot = avanti($div);
            break;

          case "play8":
            i++;
            tot = parseInt($("#result").text()) + newtot;
            $("#result").text(tot);
            var $div = $("#nove");
            newtot = avanti($div);
            newtot2 = avanti($div);
            break;

          case "play9":
            i++;
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);
            var $div = $("#dieci");
            newtot = avanti($div);
            break;

          case "play16":
            i++;
            tot = parseInt($("#result").text()) + newtot2;
            $("#result").text(tot);
            var $div = $("#quindici");
            newtot2 = avanti($div);
            break;

          default:
            i++;
            break;
        }

        if (tot <= 0 || tot >= 21) {
          alert("Hai perso!!!");
          location.reload();
        }
        if (i >= 15) {
          alert(i);
          alert("Hai vinto!!!");
          location.reload();
        }

      }
    });
  });

  function calcoloris(indice) {
    var risultato;

    /*if (indice == 0) {
      risultato = 1;
      //alert(risultato);
    }
    else if (indice == 1) {
      risultato = 2;
      //alert(risultato);
    }
    else if (indice == 2) {
      risultato = 3;
      //alert(risultato);
    }
    else if (indice == 3) {
      risultato = 4;
      //alert(risultato);
    }
    else if (indice == 4) {
      risultato = 5;
      //alert(risultato);
    }
    else if (indice == 5) {
      risultato = 6;
      //alert(risultato);
    }
    else if (indice == 6) {
      risultato = 7;
      //alert(risultato);
    }
    else if (indice == 7) {
      risultato = 8;
      //alert(risultato);
    }
    else if (indice == 8) {
      risultato = 9;
      //alert(risultato);
    }
    else if (indice == 9) {
      risultato = -1;
    }
    else if (indice == 10) {
      risultato = -2;
    }
    else if (indice == 11) {
      risultato = -3;
    }
    else if (indice == 12) {
      risultato = -4;
    }
    else if (indice == 13) {
      risultato = -5;
    }
    else if (indice == 14) {
      risultato = -6;
    }
    else if (indice == 15) {
      risultato = -7;
    }
    else if (indice == 16) {
      risultato = -8;
    }
    else if (indice == 17) {
      risultato = -9;
    }*/

    switch (indice) {
      case 0:
        risultato = 1;
        break;

      case 1:
        risultato = 2;
        break;

      case 2:
        risultato = 3;
        break;

      case 3:
        risultato = 4;
        break;

      case 4:
        risultato = 5;
        break;

      case 5:
        risultato = 6;
        break;

      case 6:
        risultato = 7;
        break;

      case 7:
        risultato = 8;
        break;

      case 8:
        risultato = 9;
        break;

      case 9:
        risultato = -1;
        break;

      case 10:
        risultato = -2;
        break;

      case 11:
        risultato = -3;
        break;

      case 12:
        risultato = -4;
        break;

      case 13:
        risultato = -5;
        break;

      case 14:
        risultato = -6;
        break;

      case 15:
        risultato = -7;
        break;

      case 16:
        risultato = -8;
        break;

      case 17:
        risultato = -9;
        break;
    }

    return risultato;

  };

  $(function () {
    var images = ["../images/verde/1.png", "../images/verde/2.png", "../images/verde/3.png", "../images/verde/4.png", "../images/verde/5.png", "../images/verde/6.png", "../images/verde/7.png", "../images/verde/8.png", "../images/verde/9.png", "../images/rosso/1.png", "../images/rosso/2.png", "../images/rosso/3.png", "../images/rosso/4.png", "../images/rosso/5.png", "../images/rosso/6.png", "../images/rosso/7.png", "../images/rosso/8.png", "../images/rosso/9.png"];
    var randomIndex = Math.floor(Math.random() * images.length);
    var randomImage = images[randomIndex]; // recuperiamo l'elemento dell'array corrispondente all'indice
    var indice = randomIndex; // memorizza l'indice estratto dall'array
    //alert(indice);
    //alert(randomImage);

    $("#uno").css("background-image", "url('" + randomImage + "')");
    risultato1 = calcoloris(indice);

    var randomIndex = Math.floor(Math.random() * images.length);
    var randomImage = images[randomIndex];
    $("#quindici").css("background-image", "url('" + randomImage + "')");
    risultato2 = calcoloris(randomIndex);
  });

  $(function () {
    $("div[name='play1'],div[name='play2'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6'],div[name='play15'],div[name='play14'],div[name='play7'],div[name='play8'],div[name='play9'],div[name='play10'],div[name='play11'],div[name='play12'],div[name='play13'],div[name='play16']").draggable({
      revert: function (event, ui) {
        $(this).data("uiDraggable").originalPosition = {
          top: 0,
          left: 0
        };
        return !event;
      }
    });
  });

  $("#result, #hold").droppable({
    accept: function (draggable) {
      var cardName = draggable.attr('name');
      var cardNumber = parseInt(cardName.replace('play', ''));
      return (cardNumber < minCardNumber || cardNumber > maxCardNumber);
    }
  });

  var minCardNumber = 2;
  var maxCardNumber = 14;
  var k = 0;
  function avanti($div) {
    var images = ["../images/verde/1.png", "../images/verde/2.png", "../images/verde/3.png", "../images/verde/4.png", "../images/verde/5.png", "../images/verde/6.png", "../images/verde/7.png", "../images/verde/8.png", "../images/verde/9.png", "../images/rosso/1.png", "../images/rosso/2.png", "../images/rosso/3.png", "../images/rosso/4.png", "../images/rosso/5.png", "../images/rosso/6.png", "../images/rosso/7.png", "../images/rosso/8.png", "../images/rosso/9.png"];
    var randomIndex = Math.floor(Math.random() * images.length);
    var randomImage = images[randomIndex];
    var indice = randomIndex;
    k++;
    if (k >= 15) {
      alert("Hai vinto!!!");
      location.reload();
    }
    $div.css("background-image", "url('" + randomImage + "')");
    var newris;
    newris = calcoloris(indice);
    var cardName = $div.attr('name');
    var cardNumber = parseInt(cardName.replace('play', ''));

    if (cardNumber > 0 && cardNumber < 9) {
      minCardNumber++;
    }

    else if (cardNumber > 8 && cardNumber < 16) {
      maxCardNumber--;
    }


    return newris;
  }

  /*$(function () {
    // Salva il testo originale di #hold in una variabile
    var originalHoldText = $('#hold').text();

    $("div[name='play1'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6']").draggable({
      helper: 'clone',  // Non creare un clone
      stop: function (event, ui) {
        // Ripristina il testo originale di #hold quando la carta viene droppata fuori
        $('#hold').text(originalHoldText);
      }
    });

    $("#hold").droppable({
      drop: function (event, ui) {
        $(this).empty();  // Elimina il contenuto precedente di #hold
        $(this).append(ui.draggable);
        $("#hold div").css({ "margin": "0", "padding": "0", "width": "96px", "height": "127px" });

        // Rimuovi il testo di #hold quando una carta viene droppata all'interno
        $(this).text("");
      }
    });

    $("body").droppable({
      drop: function (event, ui) {
        if ($(ui.draggable).parent().attr('id') === 'hold') {
          $(this).append(ui.draggable);
        }
      }
    });
  });*/


  $(function () {
    var k = 0;
    $("div[name='play1'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6']").draggable({
      helper: 'original',
      revert: 'invalid'
    });
    k++;
    $("#hold").droppable({
      accept: function (draggable) {
        return $(this).has(draggable).length === 0;
      },
      drop: function (event, ui) {
        $(this).text("");
        $(ui.draggable).appendTo($(this)).css({
          'top': '0px',
          'left': '0px',
          'position': 'relative',
          'margin': '0px',
          'padding': '0px'
        });
        /*if (k == 1) {
          var $div = $("#due");
          newtot = avanti($div);
          hold = true;
        }
        if (k == 2) {
          var $div = $("#quattordici");
          newtot = avanti($div);
          hold = true;
        }*/
        //var $div = $("#otto");
        //newtot = avanti($div);
      }
    });

    $("div[name='play1'],div[name='play3'],div[name='play4'],div[name='play5'],div[name='play6']").droppable({
      accept: "#hold div",
      drop: function (event, ui) {
        $(ui.draggable).appendTo($(this).parent()).css({
          'top': '0px',
          'left': '0px',
          'position': 'relative'
        });
      }
    });

    $("#hold").on("dragleave", function (event, ui) {
      $(this).text("HOLD");
    });
  });
});